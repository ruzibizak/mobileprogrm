import 'package:flutter/material.dart';

// Creating a Stateless Widget for buttons
class MyButton extends StatelessWidget {
  // Declaring variables
  final Color? color;
  final Color? textColor;
  final String? buttonText;
  final Function? buttontapped;

  // Constructor
  MyButton({this.color, this.textColor, this.buttonText, this.buttontapped});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        try {
          buttontapped?.call();
        } catch (e) {
          print('Error in onTap: $e');
          // Handle the error or log it as needed
        }
      },
      child: Padding(
        padding: const EdgeInsets.all(0.2),
        child: ClipRRect(
          child: Container(
            color: color ?? Colors.green, // Use green as the default color if color is null
            child: Center(
              child: Text(
                buttonText ?? 'Default Text', // Use 'Default Text' if buttonText is null
                style: TextStyle(
                  color: textColor ?? Colors.black, // Use black as the default color if textColor is null
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
